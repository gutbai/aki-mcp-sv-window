# Batch 26 recovery checkpoint

The ChatGPT labeling session repeatedly hit message-stream timeouts.

Status:
- batch_26_img001..img040: review session reached these images; coordinates below use the refined proposal centers produced during that review.
- batch_26_img041..img050: not fully reviewed after the last timeout; preserved from the existing auto-match checkpoint.
- LOW_CONFIDENCE is retained for known weak matcher cases among the unfinished tail.
- This is intentionally a PARTIAL/RECOVERY checkpoint, not the final benchmark submission.
- batch_23, batch_24 and batch_25 were already finalized and pushed separately.
- batch_27 was already finalized separately.

Resume from batch_26_img041.
